package com.demo3.fxml_3;

public class SearchPanel {
}
